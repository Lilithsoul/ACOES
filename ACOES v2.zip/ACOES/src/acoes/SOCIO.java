/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acoes;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;

/**
 *
 * @author katiucha
 */

@MappedSuperclass
public class SOCIO extends USUARIO implements Serializable{
    
    private String num_cuenta_bancaria;
    

    public String getNum_cuenta_bancaria() {
        return num_cuenta_bancaria;
    }

    public void setNum_cuenta_bancaria(String num_cuenta_bancaria) {
        this.num_cuenta_bancaria = num_cuenta_bancaria;
    }
    
    @OneToMany(mappedBy="socio")
    List<HISTORIAL_APADRINAMIENTO> apadrinamiento;

    public List<HISTORIAL_APADRINAMIENTO> getApadrinamiento() {
        return apadrinamiento;
    }

    public void setApadrinamiento(List<HISTORIAL_APADRINAMIENTO> apadrinamiento) {
        this.apadrinamiento = apadrinamiento;
    }
    
}
