/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package acoes;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Temporal;


/**
 *
 * @author katiucha
 */
@Entity
public class ADMIN extends USUARIO implements Serializable {
    private String num_SS;
    private String seccion_operativa;
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date fecha_Entrada;
    private double sueldo;
    private double importeBruto;


    public String getNum_SS() {
        return num_SS;
    }

 

    public void setNum_SS(String num_SS) {
        this.num_SS = num_SS;
    }

    public String getSeccion_operativa() {
        return seccion_operativa;
    }

    public void setSeccion_operativa(String seccion_operativa) {
        this.seccion_operativa = seccion_operativa;
    }

    public Date getFecha_Entrada() {
        return fecha_Entrada;
    }

    public void setFecha_Entrada(Date fecha_Entrada) {
        this.fecha_Entrada = fecha_Entrada;
    }

    public double getSueldo() {
        return sueldo;
    }

    public void setSueldo(double sueldo) {
        this.sueldo = sueldo;
    }

    public double getImporteBruto() {
        return importeBruto;
    }

    public void setImporteBruto(double importeBruto) {
        this.importeBruto = importeBruto;
    }
    
    
}
